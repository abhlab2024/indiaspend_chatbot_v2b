// import { createSlice } from "@reduxjs/toolkit";

// const idSlice = createSlice({
//   name: "userId",
//   initialState: { id: null }, // Default ID null rakhein
//   reducers: {
//     setId: (state, action) => {
//       state.id = action.payload;
//     },
//     clearId: (state) => {
//       state.id = null;
//     },
//   },
// });

// export const { setId, clearId } = idSlice.actions;
// export default idSlice.reducer;
