// import { createSlice } from "@reduxjs/toolkit";

// const chartHistorySlice = createSlice({
//   name: "chartHistory",
//   initialState: {
//     history: [],
//   },
//   reducers: {
//     addEntry: (state, action) => {
//       state.history.push(action.payload);
//     },
//     clearHistory: (state) => {
//       state.history = [];
//     },
//   },
// });

// export const { addEntry, clearHistory } = chartHistorySlice.actions;
// export default chartHistorySlice.reducer;
